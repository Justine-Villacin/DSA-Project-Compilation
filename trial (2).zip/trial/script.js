// ==========================
// APPLICATION STATE
// ==========================
let notesData = [];
let currentDate = new Date();
let calendarDate = new Date();
let popupCalendarDate = new Date();
let currentPage = 'home';

// Mood mapping
const moodMap = {
  "😊": "Happy",
  "🙂": "Content",
  "😐": "Neutral", 
  "🙁": "Sad",
  "😣": "Stressed"
};

// API base URL
const API_BASE = 'http://127.0.0.1:5000/api';

// ==========================
// INITIALIZATION
// ==========================
document.addEventListener('DOMContentLoaded', () => {
  initializeNavigation();
  initializeHomePage();
  initializeNotePopup();
  initializeGallery();
  initializeCalendar();
  
  // Load initial data
  loadNotesData().then(() => {
    // Show home page by default
    showPage('home');
  });
});

// ==========================
// API FUNCTIONS
// ==========================
async function loadNotesData() {
  try {
    const response = await fetch(`${API_BASE}/notes`);
    notesData = await response.json();
  } catch (error) {
    console.error('Error loading notes:', error);
    notesData = [];
  }
}

async function saveNote(note) {
  try {
    const response = await fetch(`${API_BASE}/notes`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(note)
    });
    
    if (response.ok) {
      const result = await response.json();
      // Add the new note to local state
      notesData.unshift(result.note);
      return true;
    } else {
      console.error('Failed to save note');
      return false;
    }
  } catch (error) {
    console.error('Error saving note:', error);
    return false;
  }
}

async function loadPhotos(dateFilter = 'all', moodFilter = 'all') {
  try {
    const params = new URLSearchParams();
    if (dateFilter !== 'all') params.append('date_filter', dateFilter);
    if (moodFilter !== 'all') params.append('mood_filter', moodFilter);
    
    const response = await fetch(`${API_BASE}/photos?${params}`);
    return await response.json();
  } catch (error) {
    console.error('Error loading photos:', error);
    return [];
  }
}

async function loadCalendarData(year, month) {
  try {
    const response = await fetch(`${API_BASE}/calendar/${year}/${month}`);
    return await response.json();
  } catch (error) {
    console.error('Error loading calendar data:', error);
    return {};
  }
}

// ==========================
// MODIFIED FUNCTIONS FOR API INTEGRATION
// ==========================

// In initializeNotePopup(), modify the save note section:
async function saveNoteToBackend() {
  const noteText = noteTextarea.value.trim();
  if (!noteText) {
    alert('Please write something in your note');
    return;
  }

  const selectedDate = new Date(popupCalendarDate);
  selectedDate.setHours(currentDate.getHours(), currentDate.getMinutes());
  
  const note = {
    mood: moodIcon.textContent,
    date: selectedDate.toISOString(),
    text: noteText,
    photos: [...currentPhotos]
  };

  // Save note to backend
  const success = await saveNote(note);
  
  if (success) {
    // Show success message
    showSuccessMessage();
    
    // Close popup
    overlay.classList.remove('active');
    
    // Refresh display if on home page
    if (currentPage === 'home') {
      renderNotesForDate(currentDate);
    }
  } else {
    alert('Failed to save note. Please try again.');
  }
}

// In gallery.loadPhotos(), modify to use API:
async function loadGalleryPhotos() {
  const dateFilter = document.getElementById('dateFilter').value;
  const moodFilter = document.getElementById('moodFilter').value;
  
  this.photos = await loadPhotos(dateFilter, moodFilter);
}

// In calendar.renderCalendar(), modify to use API:
async function renderCalendarWithAPI() {
  // ... existing calendar rendering code ...
  
  // Get calendar data from API
  const year = this.currentDate.getFullYear();
  const month = this.currentDate.getMonth() + 1; // API expects 1-12
  const calendarData = await loadCalendarData(year, month);
  
  // Use calendarData to populate the calendar view
  // ... rest of calendar rendering logic ...
}

// ==========================
// DELETE NOTE FUNCTIONALITY
// ==========================

async function deleteNote(noteId) {
    if (!confirm('Are you sure you want to delete this note?')) {
        return;
    }

    try {
        const response = await fetch(`${API_BASE}/notes/${noteId}`, {
            method: 'DELETE'
        });
        
        if (response.ok) {
            // Remove note from local state
            notesData = notesData.filter(note => note.id !== noteId);
            
            // Refresh the display
            if (currentPage === 'home') {
                renderNotesForDate(currentDate);
            } else if (currentPage === 'calendar') {
                renderCalendarWithAPI();
            }
            
            // Show success message
            showSuccessMessage('Note deleted successfully!');
        } else {
            alert('Failed to delete note. Please try again.');
        }
    } catch (error) {
        console.error('Error deleting note:', error);
        alert('Error deleting note. Please try again.');
    }
}

// Modify the showSuccessMessage function to accept custom messages
function showSuccessMessage(message = 'Note saved successfully!') {
    const successMessage = document.getElementById('successMessage');
    successMessage.textContent = message;
    successMessage.classList.add('show');
    
    setTimeout(() => {
        successMessage.classList.remove('show');
    }, 3000);
}

// Update the renderNotesForDate function to include delete buttons
function renderNotesForDate(date) {
    const container = document.getElementById('savedNotesContainer');
    const noEntries = document.getElementById('noEntries');
    
    const dateStr = date.toISOString().split('T')[0];
    const notesForDate = notesData.filter(note => 
        note.date.split('T')[0] === dateStr
    );
    
    if (notesForDate.length === 0) {
        container.innerHTML = '';
        noEntries.style.display = 'block';
        return;
    }
    
    noEntries.style.display = 'none';
    
    // Sort notes by time (most recent first)
    notesForDate.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    container.innerHTML = notesForDate.map(note => `
        <div class="note-card" data-note-id="${note.id}">
            <div class="note-actions" style="position: relative; top: 0; right: 0;">
                <button class="delete-note-btn" onclick="deleteNote(${note.id})" title="Delete note">🗑️</button>
            </div>
            <div class="note-header">
                <span class="note-mood">${note.mood}</span>
                <span class="note-time">${formatTime(new Date(note.date))}</span>
            </div>
            <div class="note-text">${note.text}</div>
            ${note.photos && note.photos.length > 0 ? `
                <div class="note-photos">
                    ${note.photos.map(photo => `
                        <img src="${photo}" alt="Note photo" class="note-photo" onclick="openPhotoModal('${photo}', '${note.mood}', '${new Date(note.date).toLocaleDateString()}', '${note.text.replace(/'/g, "\\'")}')">
                    `).join('')}
                </div>
            ` : ''}
        </div>
    `).join('');
}

// Add CSS for delete button (add this to styles.css)
const deleteButtonCSS = `
.delete-note-btn {
    background: none;
    border: none;
    cursor: pointer;
    font-size: 18px;
    padding: 5px;
    border-radius: 50%;
    transition: all 0.2s ease;
}

.delete-note-btn:hover {
    background-color: rgba(255, 0, 0, 0.1);
    transform: scale(1.1);
}
`;

// Inject the CSS
const style = document.createElement('style');
style.textContent = deleteButtonCSS;
document.head.appendChild(style);

// Update the function that opens day modal to include delete buttons
function openDayModal(date) {
    const modal = document.getElementById('dayModal');
    const modalDateTitle = document.getElementById('modalDateTitle');
    const dayNotes = document.getElementById('dayNotes');
    
    const dateStr = date.toISOString().split('T')[0];
    const notesForDate = notesData.filter(note => 
        note.date.split('T')[0] === dateStr
    );
    
    modalDateTitle.textContent = date.toLocaleDateString('en-US', { 
        weekday: 'long', 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric' 
    });
    
    if (notesForDate.length === 0) {
        dayNotes.innerHTML = `
            <div class="no-notes">
                <div class="no-notes-icon">📝</div>
                <div>No notes for this day</div>
            </div>
        `;
    } else {
        // Sort notes by time (most recent first)
        notesForDate.sort((a, b) => new Date(b.date) - new Date(a.date));
        
        dayNotes.innerHTML = notesForDate.map(note => `
            <div class="note-item" data-note-id="${note.id}">
                <div class="note-actions" style="position: relative; top: 0; right: 0; justify-content: flex-end; display: flex;">
                    <button class="delete-note-btn" onclick="deleteNote(${note.id})" title="Delete note">🗑️</button>
                </div>
                <div class="note-header">
                    <span class="note-mood">${note.mood}</span>
                    <span class="note-time">${formatTime(new Date(note.date))}</span>
                </div>
                <div class="note-text">${note.text}</div>
                ${note.photos && note.photos.length > 0 ? `
                    <div class="note-photos">
                        ${note.photos.map(photo => `
                            <img src="${photo}" alt="Note photo" class="note-photo" onclick="openPhotoModal('${photo}', '${note.mood}', '${new Date(note.date).toLocaleDateString()}', '${note.text.replace(/'/g, "\\'")}')">
                        `).join('')}
                    </div>
                ` : ''}
            </div>
        `).join('');
    }
    
    modal.style.display = 'block';
}

// Update the gallery rendering to include delete buttons
function renderGalleryPhotos() {
    const container = document.getElementById('galleryContainer');
    const noPhotos = document.getElementById('noPhotos');
    
    if (this.photos.length === 0) {
        container.innerHTML = '';
        noPhotos.style.display = 'block';
        return;
    }
    
    noPhotos.style.display = 'none';
    
    container.innerHTML = this.photos.map(photo => `
        <div class="photo-card">
            <div class="photo-actions" style="position: absolute; top: 10px; right: 10px; z-index: 10;">
                <button class="delete-photo-btn" onclick="deletePhoto('${photo.src}', '${photo.date}')" title="Delete photo">🗑️</button>
            </div>
            <img src="${photo.src}" alt="Journal photo" class="photo-thumbnail" onclick="openPhotoModal('${photo.src}', '${photo.mood}', '${new Date(photo.date).toLocaleDateString()}', '${photo.text.replace(/'/g, "\\'")}')">
            <div class="photo-details">
                <div class="photo-mood">${photo.mood}</div>
                <div class="photo-date">${new Date(photo.date).toLocaleDateString()}</div>
                <div class="photo-preview">${photo.text.substring(0, 50)}${photo.text.length > 50 ? '...' : ''}</div>
            </div>
        </div>
    `).join('');
}

// Note: Deleting individual photos is more complex as it requires modifying the note
// For now, users can delete the entire note from home or calendar views