// ==========================
// APPLICATION STATE
// ==========================
let notesData = JSON.parse(localStorage.getItem('journalNotes') || '[]');
let currentDate = new Date();
let calendarDate = new Date();
let popupCalendarDate = new Date();
let currentPage = 'home';

// Mood mapping
const moodMap = {
  "😊": "Happy",
  "🙂": "Content",
  "😐": "Neutral",
  "🙁": "Sad",
  "😣": "Stressed"
};

// ==========================
// INITIALIZATION
// ==========================
document.addEventListener('DOMContentLoaded', () => {
  initializeNavigation();
  initializeHomePage();
  initializeNotePopup();
  initializeGallery();
  initializeCalendar();
  
  // Show home page by default
  showPage('home');
});

// ==========================
// NAVIGATION MANAGEMENT
// ==========================
function initializeNavigation() {
  const navLinks = document.querySelectorAll('.nav-link');
  
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const page = link.getAttribute('data-page');
      showPage(page);
      
      // Update active state
      navLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
    });
  });
}

function showPage(page) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(p => {
    p.classList.remove('active');
  });
  
  // Show selected page
  document.getElementById(`${page}-page`).classList.add('active');
  currentPage = page;
  
  // Refresh page content
  if (page === 'home') {
    updateDateDisplay();
    renderNotesForDate(currentDate);
  } else if (page === 'gallery') {
    gallery.loadPhotos();
    gallery.renderGallery();
  } else if (page === 'calendar') {
    calendar.renderCalendar();
  }
}

// ==========================
// HOME PAGE FUNCTIONALITY
// ==========================
function initializeHomePage() {
  const dateElement = document.getElementById('current-date');
  const nextArrow = document.getElementById('next');
  const prevArrow = document.getElementById('prev');
  const calendarPopup = document.getElementById('calendar-popup');
  const calendarMonthYear = document.getElementById('calendar-month-year');
  const calendarGrid = document.getElementById('calendar-grid');
  const prevMonthBtn = document.getElementById('prev-month');
  const nextMonthBtn = document.getElementById('next-month');

  // Initialize date display
  updateDateDisplay();
  generateCalendar(calendarDate);

  // Arrow navigation
  prevArrow.addEventListener('click', () => {
    currentDate.setDate(currentDate.getDate() - 1);
    updateDateDisplay();
  });

  nextArrow.addEventListener('click', () => {
    currentDate.setDate(currentDate.getDate() + 1);
    updateDateDisplay();
  });

  // Calendar popup
  dateElement.addEventListener('click', () => {
    calendarPopup.classList.toggle('active');
  });

  // Calendar navigation
  prevMonthBtn.addEventListener('click', () => {
    calendarDate.setMonth(calendarDate.getMonth() - 1);
    generateCalendar(calendarDate);
  });

  nextMonthBtn.addEventListener('click', () => {
    calendarDate.setMonth(calendarDate.getMonth() + 1);
    generateCalendar(calendarDate);
  });

  // Hide popup when clicking outside
  document.addEventListener('click', (e) => {
    if (!calendarPopup.contains(e.target) && e.target !== dateElement) {
      calendarPopup.classList.remove('active');
    }
  });
}

function updateDateDisplay() {
  const dateElement = document.getElementById('current-date');
  const nextArrow = document.getElementById('next');
  const options = { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' };
  
  const formattedDate = currentDate.toLocaleDateString('en-US', options);
  dateElement.textContent = formattedDate;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const currentDateCopy = new Date(currentDate);
  currentDateCopy.setHours(0, 0, 0, 0);
  
  nextArrow.classList.toggle('disabled', currentDateCopy.getTime() === today.getTime());
  
  renderNotesForDate(currentDate);
}

function generateCalendar(date) {
  const calendarMonthYear = document.getElementById('calendar-month-year');
  const calendarGrid = document.getElementById('calendar-grid');
  const prevMonthBtn = document.getElementById('prev-month');
  const nextMonthBtn = document.getElementById('next-month');
  
  const year = date.getFullYear();
  const month = date.getMonth();
  
  // Update calendar header
  calendarMonthYear.textContent = date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  
  // Clear previous calendar
  calendarGrid.innerHTML = '';
  
  // Add day headers
  const daysOfWeek = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  daysOfWeek.forEach(day => {
    const dayElement = document.createElement('div');
    dayElement.className = 'calendar-day';
    dayElement.textContent = day;
    calendarGrid.appendChild(dayElement);
  });
  
  // Get first day of month and number of days
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const daysInMonth = lastDay.getDate();
  const startingDay = firstDay.getDay();
  
  // Add empty cells for days before the first day of the month
  for (let i = 0; i < startingDay; i++) {
    const emptyCell = document.createElement('div');
    emptyCell.className = 'calendar-date other-month';
    calendarGrid.appendChild(emptyCell);
  }
  
  // Add days of the month
  for (let day = 1; day <= daysInMonth; day++) {
    const dateCell = document.createElement('div');
    dateCell.className = 'calendar-date';
    dateCell.textContent = day;
    
    const cellDate = new Date(year, month, day);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (cellDate.getTime() === today.getTime()) {
      dateCell.classList.add('selected');
    }
    
    dateCell.addEventListener('click', () => {
      currentDate = new Date(year, month, day);
      updateDateDisplay();
      document.getElementById('calendar-popup').classList.remove('active');
    });
    
    calendarGrid.appendChild(dateCell);
  }
  
  // Disable next month button if it's the current month
  const today = new Date();
  const isCurrentMonth = date.getMonth() === today.getMonth() && date.getFullYear() === today.getFullYear();
  nextMonthBtn.classList.toggle('disabled', isCurrentMonth);
}

function renderNotesForDate(date) {
  const container = document.getElementById('savedNotesContainer');
  const noEntries = document.getElementById('noEntries');
  
  // Filter notes for the selected date
  const dateString = date.toISOString().split('T')[0];
  const dayNotes = notesData.filter(note => note.date.split('T')[0] === dateString);
  
  if (dayNotes.length === 0) {
    container.innerHTML = '';
    noEntries.style.display = 'block';
    return;
  }
  
  noEntries.style.display = 'none';
  container.innerHTML = '';
  
  // Sort notes by time (newest first)
  dayNotes.sort((a, b) => new Date(b.date) - new Date(a.date));
  
  // Create note cards
  dayNotes.forEach(note => {
    const noteCard = document.createElement('div');
    noteCard.className = 'note-card';
    
    const noteDate = new Date(note.date);
    const timeString = noteDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    
    noteCard.innerHTML = `
      <div style="display: flex; align-items: center; gap: 10px; margin-bottom: 10px;">
        <span style="font-size: 30px;">${note.mood}</span>
        <span style="font-size: 18px; color: #91d18b;">${moodMap[note.mood]}</span>
      </div>
      <div style="color: #ccc; margin-bottom: 15px;">${timeString}</div>
      <div style="line-height: 1.5; margin-bottom: 15px;">${note.text}</div>
      ${note.photos && note.photos.length > 0 ? `
        <div style="display: flex; gap: 10px; flex-wrap: wrap;">
          ${note.photos.map(photo => `
            <img src="${photo}" style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px; border: 2px solid #555; cursor: pointer;" 
                 onclick="gallery.openPhotoModal('${photo}', '${note.mood}', '${note.date}', '${note.text.replace(/'/g, "\\'")}')">
          `).join('')}
        </div>
      ` : ''}
    `;
    
    container.appendChild(noteCard);
  });
}

// ==========================
// NOTE POPUP FUNCTIONALITY
// ==========================
function initializeNotePopup() {
  const addNoteBtn = document.getElementById('addNoteBtn');
  const overlay = document.getElementById('overlay');
  const closeNoteBtn = document.getElementById('closeNote');
  const saveNoteBtn = document.getElementById('saveNote');
  const moodSelector = document.getElementById('moodSelector');
  const moodPopup = document.getElementById('moodPopup');
  const emojis = moodPopup.querySelectorAll('.emojis span');
  const moodIcon = document.getElementById('moodIcon');
  const moodText = document.getElementById('moodText');
  const noteDate = document.getElementById('noteDate');
  const noteTime = document.getElementById('noteTime');
  const datePickerBtn = document.getElementById('datePickerBtn');
  const popupCalendar = document.getElementById('calendarPopup');
  const popupCalendarMonthYear = document.getElementById('popupCalendarMonthYear');
  const popupCalendarGrid = document.getElementById('popupCalendarGrid');
  const popupPrevMonthBtn = document.getElementById('popupPrevMonth');
  const popupNextMonthBtn = document.getElementById('popupNextMonth');
  const takePhotoBtn = document.getElementById('takePhotoBtn');
  const fromDeviceBtn = document.getElementById('fromDeviceBtn');
  const cameraInput = document.getElementById('cameraInput');
  const fileInput = document.getElementById('fileInput');
  const noteTextarea = document.getElementById('noteTextarea');
  const photoPreviewContainer = document.getElementById('photoPreviewContainer');

  let currentPhotos = [];

  // Open note popup
  addNoteBtn.addEventListener('click', () => {
    // Reset form
    moodIcon.textContent = '😊';
    moodText.textContent = 'Happy';
    noteTextarea.value = '';
    currentPhotos = [];
    photoPreviewContainer.innerHTML = '';
    
    // Set current date and time
    updatePopupDateTime();
    
    // Show overlay
    overlay.classList.add('active');
  });

  // Close note popup
  closeNoteBtn.addEventListener('click', () => {
    overlay.classList.remove('active');
  });

  // Save note
  saveNoteBtn.addEventListener('click', () => {
    const noteText = noteTextarea.value.trim();
    if (!noteText) {
      alert('Please write something in your note');
      return;
    }

    const selectedDate = new Date(popupCalendarDate);
    selectedDate.setHours(currentDate.getHours(), currentDate.getMinutes());
    
    const note = {
      id: Date.now(),
      mood: moodIcon.textContent,
      date: selectedDate.toISOString(),
      text: noteText,
      photos: [...currentPhotos]
    };

    // Save note to localStorage
    notesData.push(note);
    localStorage.setItem('journalNotes', JSON.stringify(notesData));
    
    // Show success message
    showSuccessMessage();
    
    // Close popup
    overlay.classList.remove('active');
    
    // Refresh display if on home page
    if (currentPage === 'home') {
      renderNotesForDate(currentDate);
    }
  });

  // Mood selection
  moodSelector.addEventListener('click', () => {
    moodPopup.classList.toggle('active');
  });

  emojis.forEach(emoji => {
    emoji.addEventListener('click', () => {
      moodIcon.textContent = emoji.textContent;
      moodText.textContent = moodMap[emoji.textContent];
      moodPopup.classList.remove('active');
    });
  });

  // Date picker
  datePickerBtn.addEventListener('click', () => {
    popupCalendar.classList.toggle('active');
    datePickerBtn.classList.toggle('active');
    generatePopupCalendar(popupCalendarDate);
  });

  // Popup calendar navigation
  popupPrevMonthBtn.addEventListener('click', () => {
    popupCalendarDate.setMonth(popupCalendarDate.getMonth() - 1);
    generatePopupCalendar(popupCalendarDate);
  });

  popupNextMonthBtn.addEventListener('click', () => {
    popupCalendarDate.setMonth(popupCalendarDate.getMonth() + 1);
    generatePopupCalendar(popupCalendarDate);
  });

  // Photo handling
  takePhotoBtn.addEventListener('click', () => {
    cameraInput.click();
  });

  fromDeviceBtn.addEventListener('click', () => {
    fileInput.click();
  });

  cameraInput.addEventListener('change', handlePhotoSelection);
  fileInput.addEventListener('change', handlePhotoSelection);

  function handlePhotoSelection(e) {
    const files = e.target.files;
    
    for (let file of files) {
      const reader = new FileReader();
      
      reader.onload = (event) => {
        const photoData = event.target.result;
        currentPhotos.push(photoData);
        
        // Create photo preview
        const photoItem = document.createElement('div');
        photoItem.className = 'photo-item';
        photoItem.style.position = 'relative';
        photoItem.style.display = 'inline-block';
        photoItem.style.margin = '5px';
        
        photoItem.innerHTML = `
          <img src="${photoData}" style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px; border: 2px solid white;">
          <button class="removePhotoBtn" style="position: absolute; top: -5px; right: -5px; background: #ff4d4d; color: white; border: none; border-radius: 50%; width: 20px; height: 20px; font-size: 12px; cursor: pointer;">×</button>
        `;
        
        photoPreviewContainer.appendChild(photoItem);
        
        // Add remove functionality
        const removeBtn = photoItem.querySelector('.removePhotoBtn');
        removeBtn.addEventListener('click', () => {
          const index = currentPhotos.indexOf(photoData);
          if (index > -1) {
            currentPhotos.splice(index, 1);
          }
          photoItem.remove();
        });
      };
      
      reader.readAsDataURL(file);
    }
    
    // Reset inputs
    cameraInput.value = '';
    fileInput.value = '';
  }

  function updatePopupDateTime() {
    const now = new Date();
    noteDate.textContent = now.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    noteTime.textContent = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    popupCalendarDate = new Date(now);
  }

  function generatePopupCalendar(date) {
    const year = date.getFullYear();
    const month = date.getMonth();
    
    // Update calendar header
    popupCalendarMonthYear.textContent = date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    
    // Clear previous calendar
    popupCalendarGrid.innerHTML = '';
    
    // Add day headers
    const daysOfWeek = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    daysOfWeek.forEach(day => {
      const dayElement = document.createElement('div');
      dayElement.className = 'calendar-day';
      dayElement.textContent = day;
      popupCalendarGrid.appendChild(dayElement);
    });
    
    // Get first day of month and number of days
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDay; i++) {
      const emptyCell = document.createElement('div');
      emptyCell.className = 'calendar-date other-month';
      popupCalendarGrid.appendChild(emptyCell);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const dateCell = document.createElement('div');
      dateCell.className = 'calendar-date';
      dateCell.textContent = day;
      
      const cellDate = new Date(year, month, day);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (cellDate.getTime() === today.getTime()) {
        dateCell.classList.add('selected');
      }
      
      dateCell.addEventListener('click', () => {
        popupCalendarDate = new Date(year, month, day);
        noteDate.textContent = popupCalendarDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
        popupCalendar.classList.remove('active');
        datePickerBtn.classList.remove('active');
      });
      
      popupCalendarGrid.appendChild(dateCell);
    }
    
    // Disable next month button if it's the current month
    const today = new Date();
    const isCurrentMonth = date.getMonth() === today.getMonth() && date.getFullYear() === today.getFullYear();
    popupNextMonthBtn.classList.toggle('disabled', isCurrentMonth);
  }

  // Hide popups when clicking outside
  document.addEventListener('click', (e) => {
    if (!moodPopup.contains(e.target) && e.target !== moodSelector && !moodSelector.contains(e.target)) {
      moodPopup.classList.remove('active');
    }
    
    if (!popupCalendar.contains(e.target) && e.target !== datePickerBtn && !datePickerBtn.contains(e.target)) {
      popupCalendar.classList.remove('active');
      datePickerBtn.classList.remove('active');
    }
  });
}

function showSuccessMessage() {
  const message = document.getElementById('successMessage');
  message.classList.add('show');
  
  setTimeout(() => {
    message.classList.remove('show');
  }, 3000);
}

// ==========================
// GALLERY FUNCTIONALITY
// ==========================
const gallery = {
  photos: [],
  
  initialize() {
    this.loadPhotos();
    this.setupFilters();
  },
  
  loadPhotos() {
    this.photos = [];
    
    notesData.forEach(note => {
      if (note.photos && note.photos.length > 0) {
        note.photos.forEach(photoData => {
          this.photos.push({
            src: photoData,
            mood: note.mood,
            date: note.date,
            text: note.text
          });
        });
      }
    });
  },
  
  setupFilters() {
    const dateFilter = document.getElementById('dateFilter');
    const moodFilter = document.getElementById('moodFilter');
    
    dateFilter.addEventListener('change', () => this.renderGallery());
    moodFilter.addEventListener('change', () => this.renderGallery());
  },
  
  renderGallery() {
    const container = document.getElementById('galleryContainer');
    const noPhotos = document.getElementById('noPhotos');
    const dateFilter = document.getElementById('dateFilter').value;
    const moodFilter = document.getElementById('moodFilter').value;
    
    // Filter photos
    let filteredPhotos = [...this.photos];
    
    // Date filter
    if (dateFilter !== 'all') {
      const now = new Date();
      filteredPhotos = filteredPhotos.filter(photo => {
        const photoDate = new Date(photo.date);
        
        switch (dateFilter) {
          case 'today':
            return photoDate.toDateString() === now.toDateString();
          case 'week':
            const weekAgo = new Date(now);
            weekAgo.setDate(now.getDate() - 7);
            return photoDate >= weekAgo;
          case 'month':
            return photoDate.getMonth() === now.getMonth() && 
                   photoDate.getFullYear() === now.getFullYear();
          default:
            return true;
        }
      });
    }
    
    // Mood filter
    if (moodFilter !== 'all') {
      filteredPhotos = filteredPhotos.filter(photo => photo.mood === moodFilter);
    }
    
    // Display results
    if (filteredPhotos.length === 0) {
      container.innerHTML = '';
      noPhotos.style.display = 'block';
      return;
    }
    
    noPhotos.style.display = 'none';
    container.innerHTML = '';
    
    // Sort by date (newest first)
    filteredPhotos.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    // Create photo cards
    filteredPhotos.forEach(photo => {
      const photoCard = document.createElement('div');
      photoCard.className = 'photo-card';
      
      const photoDate = new Date(photo.date);
      const dateString = photoDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      const previewText = photo.text.length > 50 ? photo.text.substring(0, 50) + '...' : photo.text;
      
      photoCard.innerHTML = `
        <img src="${photo.src}" class="photo-thumbnail" alt="Journal photo">
        <div class="photo-details">
          <div class="photo-mood">${photo.mood}</div>
          <div class="photo-date">${dateString}</div>
          <div class="photo-preview">${previewText}</div>
        </div>
      `;
      
      photoCard.addEventListener('click', () => {
        this.openPhotoModal(photo.src, photo.mood, photo.date, photo.text);
      });
      
      container.appendChild(photoCard);
    });
  },
  
  openPhotoModal(src, mood, date, text) {
    const modal = document.getElementById('photoModal');
    const modalImage = document.getElementById('modalImage');
    const modalMood = document.getElementById('modalMood');
    const modalDate = document.getElementById('modalDate');
    const modalNote = document.getElementById('modalNote');
    const closeModal = document.getElementById('closeModal');
    
    modalImage.src = src;
    modalMood.textContent = mood;
    
    const dateObj = new Date(date);
    modalDate.textContent = dateObj.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    });
    
    modalNote.textContent = text;
    
    modal.style.display = 'block';
    
    closeModal.onclick = () => {
      modal.style.display = 'none';
    };
    
    window.onclick = (e) => {
      if (e.target === modal) {
        modal.style.display = 'none';
      }
    };
  }
};

function initializeGallery() {
  gallery.initialize();
}

// ==========================
// CALENDAR FUNCTIONALITY
// ==========================
const calendar = {
  currentDate: new Date(),
  
  initialize() {
    this.setupNavigation();
  },
  
  setupNavigation() {
    const prevYearBtn = document.getElementById('prevYear');
    const prevMonthBtn = document.getElementById('prevMonth');
    const nextMonthBtn = document.getElementById('nextMonth');
    const nextYearBtn = document.getElementById('nextYear');
    
    prevYearBtn.addEventListener('click', () => {
      this.currentDate.setFullYear(this.currentDate.getFullYear() - 1);
      this.renderCalendar();
    });
    
    prevMonthBtn.addEventListener('click', () => {
      this.currentDate.setMonth(this.currentDate.getMonth() - 1);
      this.renderCalendar();
    });
    
    nextMonthBtn.addEventListener('click', () => {
      this.currentDate.setMonth(this.currentDate.getMonth() + 1);
      this.renderCalendar();
    });
    
    nextYearBtn.addEventListener('click', () => {
      this.currentDate.setFullYear(this.currentDate.getFullYear() + 1);
      this.renderCalendar();
    });
  },
  
  renderCalendar() {
    const calendarGrid = document.getElementById('calendarGrid');
    const currentMonthYear = document.getElementById('currentMonthYear');
    
    const year = this.currentDate.getFullYear();
    const month = this.currentDate.getMonth();
    
    // Update header
    currentMonthYear.textContent = this.currentDate.toLocaleDateString('en-US', { 
      month: 'long', 
      year: 'numeric' 
    });
    
    // Clear previous calendar
    calendarGrid.innerHTML = '';
    
    // Add day headers
    const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    daysOfWeek.forEach(day => {
      const dayHeader = document.createElement('div');
      dayHeader.className = 'calendar-day-header';
      dayHeader.textContent = day;
      calendarGrid.appendChild(dayHeader);
    });
    
    // Get first day of month and number of days
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDay; i++) {
      const emptyCell = document.createElement('div');
      emptyCell.className = 'calendar-day other-month';
      calendarGrid.appendChild(emptyCell);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const dayCell = document.createElement('div');
      dayCell.className = 'calendar-day';
      
      const cellDate = new Date(year, month, day);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (cellDate.getTime() === today.getTime()) {
        dayCell.classList.add('today');
      }
      
      // Get notes for this day
      const dateString = cellDate.toISOString().split('T')[0];
      const dayNotes = notesData.filter(note => note.date.split('T')[0] === dateString);
      
      // Determine dominant mood for the day
      let dominantMood = null;
      if (dayNotes.length > 0) {
        const moodCounts = {};
        dayNotes.forEach(note => {
          moodCounts[note.mood] = (moodCounts[note.mood] || 0) + 1;
        });
        
        dominantMood = Object.keys(moodCounts).reduce((a, b) => 
          moodCounts[a] > moodCounts[b] ? a : b
        );
      }
      
      // Create day content
      const dayNumber = document.createElement('div');
      dayNumber.className = 'day-number';
      dayNumber.textContent = day;
      dayCell.appendChild(dayNumber);
      
      if (dominantMood) {
        const moodElement = document.createElement('div');
        moodElement.className = 'day-mood';
        moodElement.textContent = dominantMood;
        dayCell.appendChild(moodElement);
        
        // Add mood indicator
        const moodIndicator = document.createElement('div');
        moodIndicator.className = 'mood-indicator';
        
        switch (dominantMood) {
          case '😊': moodIndicator.classList.add('mood-happy'); break;
          case '🙂': moodIndicator.classList.add('mood-content'); break;
          case '😐': moodIndicator.classList.add('mood-neutral'); break;
          case '🙁': moodIndicator.classList.add('mood-sad'); break;
          case '😣': moodIndicator.classList.add('mood-stressed'); break;
        }
        
        dayCell.appendChild(moodIndicator);
      }
      
      if (dayNotes.length > 0) {
        const previewElement = document.createElement('div');
        previewElement.className = 'day-preview';
        previewElement.textContent = dayNotes[0].text.substring(0, 30) + 
                                   (dayNotes[0].text.length > 30 ? '...' : '');
        dayCell.appendChild(previewElement);
      }
      
      // Add click event to show day notes
      dayCell.addEventListener('click', () => {
        this.showDayNotes(cellDate, dayNotes);
      });
      
      calendarGrid.appendChild(dayCell);
    }
  },
  
  showDayNotes(date, notes) {
    const modal = document.getElementById('dayModal');
    const modalDateTitle = document.getElementById('modalDateTitle');
    const dayNotes = document.getElementById('dayNotes');
    const closeModal = document.getElementById('closeDayModal');
    
    // Set modal title
    modalDateTitle.textContent = date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
    
    // Clear previous notes
    dayNotes.innerHTML = '';
    
    if (notes.length === 0) {
      dayNotes.innerHTML = `
        <div class="no-notes">
          <div class="no-notes-icon">📝</div>
          <div>No entries for this day</div>
        </div>
      `;
    } else {
      // Sort notes by time (newest first)
      notes.sort((a, b) => new Date(b.date) - new Date(a.date));
      
      // Create note items
      notes.forEach(note => {
        const noteItem = document.createElement('div');
        noteItem.className = 'note-item';
        
        const noteDate = new Date(note.date);
        const timeString = noteDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
        
        noteItem.innerHTML = `
          <div class="note-header">
            <div class="note-mood">${note.mood}</div>
            <div class="note-time">${timeString}</div>
          </div>
          <div class="note-text">${note.text}</div>
          ${note.photos && note.photos.length > 0 ? `
            <div class="note-photos">
              ${note.photos.map(photo => `
                <img src="${photo}" class="note-photo" 
                     onclick="gallery.openPhotoModal('${photo}', '${note.mood}', '${note.date}', '${note.text.replace(/'/g, "\\'")}')">
              `).join('')}
            </div>
          ` : ''}
        `;
        
        dayNotes.appendChild(noteItem);
      });
    }
    
    modal.style.display = 'block';
    
    closeModal.onclick = () => {
      modal.style.display = 'none';
    };
    
    window.onclick = (e) => {
      if (e.target === modal) {
        modal.style.display = 'none';
      }
    };
  }
};

function initializeCalendar() {
  calendar.initialize();
}