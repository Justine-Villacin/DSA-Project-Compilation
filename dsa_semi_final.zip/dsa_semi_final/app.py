# ==========================
# LINKED LIST IMPLEMENTATION
# ==========================
class Node:
    """Node for linked list storing journal notes"""
    def __init__(self, note_data):
        self.data = note_data
        self.next = None

class NotesLinkedList:
    """Linked list to store journal notes"""
    def __init__(self):
        self.head = None
        self.size = 0
    
    def add_note(self, note_data):
        """Add a new note to the beginning of the list (most recent first)"""
        new_node = Node(note_data)
        new_node.next = self.head
        self.head = new_node
        self.size += 1
        return new_node
    
    def delete_note(self, note_id):
        """Delete a note by ID"""
        if self.head is None:
            return False
        
        # If the head is the node to delete
        if self.head.data['id'] == note_id:
            self.head = self.head.next
            self.size -= 1
            return True
        
        # Search for the node to delete
        current = self.head
        while current.next:
            if current.next.data['id'] == note_id:
                current.next = current.next.next
                self.size -= 1
                return True
            current = current.next
        
        return False
    
    def get_notes_by_date(self, target_date):
        """Get all notes for a specific date"""
        notes = []
        current = self.head
        
        while current:
            # Extract just the date part (YYYY-MM-DD)
            note_date = current.data['date'].split('T')[0]
            if note_date == target_date:
                notes.append(current.data)
            current = current.next
        
        return notes
    
    def get_all_notes(self):
        """Get all notes in the list"""
        notes = []
        current = self.head
        
        while current:
            notes.append(current.data)
            current = current.next
        
        return notes
    
    def get_notes_with_photos(self):
        """Get all notes that contain photos"""
        photos = []
        current = self.head
        
        while current:
            if current.data.get('photos') and len(current.data['photos']) > 0:
                for photo_data in current.data['photos']:
                    photos.append({
                        'src': photo_data,
                        'mood': current.data['mood'],
                        'date': current.data['date'],
                        'text': current.data['text'],
                        'note_id': current.data['id']
                    })
            current = current.next
        
        return photos
    
    def get_notes_by_date_range(self, start_date, end_date):
        """Get notes within a date range"""
        notes = []
        current = self.head
        
        while current:
            note_date = current.data['date'].split('T')[0]
            if start_date <= note_date <= end_date:
                notes.append(current.data)
            current = current.next
        
        return notes

# ==========================
# JOURNAL APP BACKEND
# ==========================
import json
import os
from datetime import datetime, timedelta
from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS

class JournalAppBackend:
    def __init__(self):
        self.app = Flask(__name__, static_folder='static')
        CORS(self.app)
        self.notes_list = NotesLinkedList()
        self.data_file = 'journal_data.json'
        self.mood_map = {
            "😊": "Happy",
            "🙂": "Content", 
            "😐": "Neutral",
            "🙁": "Sad",
            "😣": "Stressed"
        }
        
        self.load_data()
        self.setup_routes()
    
    def load_data(self):
        """Load notes data from JSON file into linked list"""
        if os.path.exists(self.data_file):
            try:
                with open(self.data_file, 'r') as f:
                    notes_data = json.load(f)
                    # Add notes to linked list in reverse order to maintain chronology
                    for note in reversed(notes_data):
                        self.notes_list.add_note(note)
                print(f"Loaded {self.notes_list.size} notes from storage")
            except Exception as e:
                print(f"Error loading data: {e}")
                # Initialize with empty linked list
                self.notes_list = NotesLinkedList()
    
    def save_data(self):
        """Save linked list data to JSON file"""
        try:
            all_notes = self.notes_list.get_all_notes()
            with open(self.data_file, 'w') as f:
                json.dump(all_notes, f, indent=2)
            print(f"Saved {len(all_notes)} notes to storage")
        except Exception as e:
            print(f"Error saving data: {e}")
    
    def setup_routes(self):
        """Setup Flask routes"""
        
        # Serve static files (HTML, CSS, JS)
        @self.app.route('/')
        def serve_index():
            return send_from_directory('.', 'index.html')
        
        @self.app.route('/<path:path>')
        def serve_static(path):
            return send_from_directory('.', path)
        
        # API Routes
        @self.app.route('/api/notes', methods=['GET'])
        def get_notes():
            """Get all notes or filter by date"""
            date_filter = request.args.get('date')
            
            if date_filter:
                notes = self.notes_list.get_notes_by_date(date_filter)
            else:
                notes = self.notes_list.get_all_notes()
            
            return jsonify(notes)
        
        @self.app.route('/api/notes', methods=['POST'])
        def add_note():
            """Add a new note"""
            try:
                note_data = request.get_json()
                
                # Validate required fields
                if not note_data.get('text') or not note_data.get('mood'):
                    return jsonify({'error': 'Text and mood are required'}), 400
                
                # Handle date - use the provided date or current date
                if note_data.get('date'):
                    # Parse the provided date string
                    try:
                        # If it's a full ISO string, use it directly
                        if 'T' in note_data['date']:
                            # Parse as local time and ensure we keep it as local
                            note_date = datetime.fromisoformat(note_data['date'].replace('Z', '+00:00'))
                        else:
                            # If it's just a date, combine with current time
                            date_part = datetime.fromisoformat(note_data['date']).date()
                            current_time = datetime.now().time()
                            note_date = datetime.combine(date_part, current_time)
                        
                        # Store as ISO format WITHOUT timezone conversion
                        note_data['date'] = note_date.isoformat()
                    except ValueError as e:
                        return jsonify({'error': f'Invalid date format: {str(e)}'}), 400
                else:
                    # Use current date and time if no date provided
                    note_data['date'] = datetime.now().isoformat()
                
                # Add ID if not provided
                if not note_data.get('id'):
                    note_data['id'] = int(datetime.now().timestamp() * 1000)
                
                # Ensure photos list exists
                if 'photos' not in note_data:
                    note_data['photos'] = []
                
                # Add to linked list
                self.notes_list.add_note(note_data)
                
                # Save to persistent storage
                self.save_data()
                
                return jsonify({'message': 'Note added successfully', 'note': note_data}), 201
                
            except Exception as e:
                return jsonify({'error': str(e)}), 500
        
        @self.app.route('/api/notes/<int:note_id>', methods=['DELETE'])
        def delete_note(note_id):
            """Delete a note by ID"""
            try:
                if self.notes_list.delete_note(note_id):
                    self.save_data()
                    return jsonify({'message': 'Note deleted successfully'}), 200
                else:
                    return jsonify({'error': 'Note not found'}), 404
            except Exception as e:
                return jsonify({'error': str(e)}), 500
        
        @self.app.route('/api/photos', methods=['GET'])
        def get_photos():
            """Get all photos with filtering options"""
            date_filter = request.args.get('date_filter', 'all')
            mood_filter = request.args.get('mood_filter', 'all')
            
            all_photos = self.notes_list.get_notes_with_photos()
            filtered_photos = []
            
            for photo in all_photos:
                # Date filtering
                if date_filter != 'all':
                    photo_date = photo['date'].split('T')[0]
                    today = datetime.now().date()
                    
                    if date_filter == 'today':
                        if photo_date != today.isoformat():
                            continue
                    elif date_filter == 'week':
                        week_ago = today - timedelta(days=7)
                        if photo_date < week_ago.isoformat():
                            continue
                    elif date_filter == 'month':
                        photo_dt = datetime.fromisoformat(photo['date']).date()
                        if photo_dt.month != today.month or photo_dt.year != today.year:
                            continue
                
                # Mood filtering
                if mood_filter != 'all' and photo['mood'] != mood_filter:
                    continue
                
                filtered_photos.append(photo)
            
            return jsonify(filtered_photos)
        
        @self.app.route('/api/calendar/<int:year>/<int:month>', methods=['GET'])
        def get_calendar_data(year, month):
            """Get calendar data for a specific month"""
            try:
                # Calculate date range for the month
                start_date = datetime(year, month, 1).date()
                if month == 12:
                    end_date = datetime(year + 1, 1, 1).date() - timedelta(days=1)
                else:
                    end_date = datetime(year, month + 1, 1).date() - timedelta(days=1)
                
                # Get notes for this month
                month_notes = []
                current = self.notes_list.head
                while current:
                    try:
                        # Parse the note date as local time
                        note_date_str = current.data['date']
                        if 'T' in note_date_str:
                            # Parse as local datetime
                            note_datetime = datetime.fromisoformat(note_date_str.replace('Z', '+00:00'))
                        else:
                            # If it's just a date string, parse as date
                            note_datetime = datetime.fromisoformat(note_date_str)
                        
                        note_date = note_datetime.date()
                        
                        if start_date <= note_date <= end_date:
                            month_notes.append(current.data)
                    except Exception as e:
                        print(f"Error parsing note date: {e}")
                        # Skip notes with invalid dates
                        
                    current = current.next
                
                # Organize by day
                calendar_data = {}
                for note in month_notes:
                    try:
                        # Extract just the date part (YYYY-MM-DD)
                        note_date_str = note['date']
                        if 'T' in note_date_str:
                            note_datetime = datetime.fromisoformat(note_date_str.replace('Z', '+00:00'))
                            note_date = note_datetime.date().isoformat()
                        else:
                            note_date = note_date_str.split(' ')[0]  # Handle space-separated formats
                        
                        if note_date not in calendar_data:
                            calendar_data[note_date] = {
                                'notes': []
                            }
                        calendar_data[note_date]['notes'].append(note)
                    except Exception as e:
                        print(f"Error processing note for calendar: {e}")
                        continue
                
                return jsonify(calendar_data)
                
            except Exception as e:
                print(f"Error in calendar data: {e}")
                return jsonify({'error': str(e)}), 500
        
        @self.app.route('/api/stats', methods=['GET'])
        def get_stats():
            """Get statistics about notes"""
            all_notes = self.notes_list.get_all_notes()
            
            if not all_notes:
                return jsonify({
                    'total_notes': 0,
                    'mood_distribution': {},
                    'notes_with_photos': 0,
                    'recent_activity': []
                })
            
            # Mood distribution
            mood_distribution = {}
            for note in all_notes:
                mood = note['mood']
                mood_distribution[mood] = mood_distribution.get(mood, 0) + 1
            
            # Notes with photos
            notes_with_photos = sum(1 for note in all_notes if note.get('photos') and len(note['photos']) > 0)
            
            # Recent activity (last 7 days)
            recent_activity = []
            today = datetime.now().date()
            for i in range(7):
                date = today - timedelta(days=i)
                date_str = date.isoformat()
                day_notes = self.notes_list.get_notes_by_date(date_str)
                recent_activity.append({
                    'date': date_str,
                    'count': len(day_notes)
                })
            
            return jsonify({
                'total_notes': len(all_notes),
                'mood_distribution': mood_distribution,
                'notes_with_photos': notes_with_photos,
                'recent_activity': recent_activity
            })
    
    def run(self, host='127.0.0.1', port=5000, debug=True):
        """Run the Flask application"""
        print(f"Starting Journal App Backend on http://{host}:{port}")
        self.app.run(host=host, port=port, debug=debug)

# ==========================
# USAGE EXAMPLE
# ==========================
if __name__ == '__main__':
    # Create and run the backend
    backend = JournalAppBackend()
    backend.run()