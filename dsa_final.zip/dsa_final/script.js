// ==========================
// APPLICATION STATE
// ==========================
let notesData = [];
let currentDate = new Date();
let calendarDate = new Date();
let popupCalendarDate = new Date();
let currentPage = 'home';

// Mood mapping
const moodMap = {
  "😊": "Happy",
  "🙂": "Content",
  "😐": "Neutral",
  "🙁": "Sad",
  "😣": "Stressed"
};

// API Base URL
const API_BASE = 'http://127.0.0.1:5000/api';

// ==========================
// INITIALIZATION
// ==========================
document.addEventListener('DOMContentLoaded', () => {
  initializeNavigation();
  initializeHomePage();
  initializeNotePopup();
  initializeGallery();
  initializeCalendar();
  
  // Show home page by default
  showPage('home');
});

// ==========================
// API FUNCTIONS
// ==========================
async function fetchNotes(date = null) {
  try {
    let url = `${API_BASE}/notes`;
    if (date) {
      // Ensure date is in YYYY-MM-DD format
      const dateObj = new Date(date);
      const formattedDate = formatDateForAPI(dateObj);
      url = `${API_BASE}/notes?date=${formattedDate}`;
    }
    
    const response = await fetch(url);
    if (!response.ok) throw new Error('Failed to fetch notes');
    return await response.json();
  } catch (error) {
    console.error('Error fetching notes:', error);
    return [];
  }
}

async function saveNote(note) {
  try {
    const response = await fetch(`${API_BASE}/notes`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(note)
    });
    
    if (!response.ok) throw new Error('Failed to save note');
    return await response.json();
  } catch (error) {
    console.error('Error saving note:', error);
    throw error;
  }
}

async function deleteNote(noteId) {
  try {
    const response = await fetch(`${API_BASE}/notes/${noteId}`, {
      method: 'DELETE'
    });
    
    if (!response.ok) throw new Error('Failed to delete note');
    return await response.json();
  } catch (error) {
    console.error('Error deleting note:', error);
    throw error;
  }
}

async function fetchPhotos(dateFilter = 'all', moodFilter = 'all') {
  try {
    const response = await fetch(`${API_BASE}/photos?date_filter=${dateFilter}&mood_filter=${moodFilter}`);
    if (!response.ok) throw new Error('Failed to fetch photos');
    return await response.json();
  } catch (error) {
    console.error('Error fetching photos:', error);
    return [];
  }
}

// ==========================
// UTILITY FUNCTIONS
// ==========================
function formatDateForAPI(date) {
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

function areDatesEqual(date1, date2) {
  return formatDateForAPI(date1) === formatDateForAPI(date2);
}

// ==========================
// NAVIGATION MANAGEMENT
// ==========================
function initializeNavigation() {
  const navLinks = document.querySelectorAll('.nav-link');
  
  navLinks.forEach(link => {
    link.addEventListener('click', (e) => {
      e.preventDefault();
      const page = link.getAttribute('data-page');
      showPage(page);
      
      // Update active state
      navLinks.forEach(l => l.classList.remove('active'));
      link.classList.add('active');
    });
  });
}

function showPage(page) {
  // Hide all pages
  document.querySelectorAll('.page').forEach(p => {
    p.classList.remove('active');
  });
  
  // Show selected page
  document.getElementById(`${page}-page`).classList.add('active');
  currentPage = page;
  
  // Refresh page content
  if (page === 'home') {
    updateDateDisplay();
    renderNotesForDate(currentDate);
  } else if (page === 'gallery') {
    gallery.renderGallery();
  } else if (page === 'calendar') {
    calendar.renderCalendar();
  }
}

// ==========================
// HOME PAGE FUNCTIONALITY
// ==========================
function initializeHomePage() {
  const dateElement = document.getElementById('current-date');
  const nextArrow = document.getElementById('next');
  const prevArrow = document.getElementById('prev');
  const calendarPopup = document.getElementById('calendar-popup');
  const calendarMonthYear = document.getElementById('calendar-month-year');
  const calendarGrid = document.getElementById('calendar-grid');
  const prevMonthBtn = document.getElementById('prev-month');
  const nextMonthBtn = document.getElementById('next-month');

  // Initialize date display
  updateDateDisplay();
  generateCalendar(calendarDate);

  // Arrow navigation
  prevArrow.addEventListener('click', () => {
    currentDate.setDate(currentDate.getDate() - 1);
    updateDateDisplay();
  });

  nextArrow.addEventListener('click', () => {
    currentDate.setDate(currentDate.getDate() + 1);
    updateDateDisplay();
  });

  // Calendar popup
  dateElement.addEventListener('click', () => {
    calendarPopup.classList.toggle('active');
  });

  // Calendar navigation
  prevMonthBtn.addEventListener('click', () => {
    calendarDate.setMonth(calendarDate.getMonth() - 1);
    generateCalendar(calendarDate);
  });

  nextMonthBtn.addEventListener('click', () => {
    calendarDate.setMonth(calendarDate.getMonth() + 1);
    generateCalendar(calendarDate);
  });

  // Hide popup when clicking outside
  document.addEventListener('click', (e) => {
    if (!calendarPopup.contains(e.target) && e.target !== dateElement) {
      calendarPopup.classList.remove('active');
    }
  });
}

function updateDateDisplay() {
  const dateElement = document.getElementById('current-date');
  const nextArrow = document.getElementById('next');
  const options = { weekday: 'long', month: 'long', day: 'numeric', year: 'numeric' };
  
  const formattedDate = currentDate.toLocaleDateString('en-US', options);
  dateElement.textContent = formattedDate;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  const currentDateCopy = new Date(currentDate);
  currentDateCopy.setHours(0, 0, 0, 0);
  
  nextArrow.classList.toggle('disabled', currentDateCopy.getTime() === today.getTime());
  
  renderNotesForDate(currentDate);
}

function generateCalendar(date) {
  const calendarMonthYear = document.getElementById('calendar-month-year');
  const calendarGrid = document.getElementById('calendar-grid');
  const prevMonthBtn = document.getElementById('prev-month');
  const nextMonthBtn = document.getElementById('next-month');
  
  const year = date.getFullYear();
  const month = date.getMonth();
  
  // Update calendar header
  calendarMonthYear.textContent = date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
  
  // Clear previous calendar
  calendarGrid.innerHTML = '';
  
  // Add day headers
  const daysOfWeek = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
  daysOfWeek.forEach(day => {
    const dayElement = document.createElement('div');
    dayElement.className = 'calendar-day';
    dayElement.textContent = day;
    calendarGrid.appendChild(dayElement);
  });
  
  // Get first day of month and number of days
  const firstDay = new Date(year, month, 1);
  const lastDay = new Date(year, month + 1, 0);
  const daysInMonth = lastDay.getDate();
  const startingDay = firstDay.getDay();
  
  // Add empty cells for days before the first day of the month
  for (let i = 0; i < startingDay; i++) {
    const emptyCell = document.createElement('div');
    emptyCell.className = 'calendar-date other-month';
    calendarGrid.appendChild(emptyCell);
  }
  
  // Add days of the month
  for (let day = 1; day <= daysInMonth; day++) {
    const dateCell = document.createElement('div');
    dateCell.className = 'calendar-date';
    dateCell.textContent = day;
    
    const cellDate = new Date(year, month, day);
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    if (cellDate.getTime() === today.getTime()) {
      dateCell.classList.add('selected');
    }
    
    dateCell.addEventListener('click', () => {
      currentDate = new Date(year, month, day);
      updateDateDisplay();
      document.getElementById('calendar-popup').classList.remove('active');
    });
    
    calendarGrid.appendChild(dateCell);
  }
  
  // Disable next month button if it's the current month
  const today = new Date();
  const isCurrentMonth = date.getMonth() === today.getMonth() && date.getFullYear() === today.getFullYear();
  nextMonthBtn.classList.toggle('disabled', isCurrentMonth);
}

async function renderNotesForDate(date) {
  const container = document.getElementById('savedNotesContainer');
  const noEntries = document.getElementById('noEntries');
  
  try {
    // Fetch notes for the selected date from backend
    const dateString = formatDateForAPI(date);
    const dayNotes = await fetchNotes(dateString);
    
    if (dayNotes.length === 0) {
      container.innerHTML = '';
      noEntries.style.display = 'block';
      return;
    }
    
    noEntries.style.display = 'none';
    container.innerHTML = '';
    
    // Sort notes by time (newest first)
    dayNotes.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    // Create note cards
    dayNotes.forEach(note => {
      const noteCard = document.createElement('div');
      noteCard.className = 'note-card';
      
      const noteDate = new Date(note.date);
      const timeString = noteDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
      
      noteCard.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: flex-start; margin-bottom: 10px;">
          <div style="display: flex; align-items: center; gap: 10px;">
            <span style="font-size: 30px;">${note.mood}</span>
            <span style="font-size: 18px; color: #91d18b;">${moodMap[note.mood]}</span>
          </div>
          <button class="delete-note-btn" data-note-id="${note.id}" style="background: #ff4d4d; color: white; border: none; border-radius: 5px; padding: 5px 10px; cursor: pointer; font-size: 12px;">Delete</button>
        </div>
        <div style="color: #ccc; margin-bottom: 15px;">${timeString}</div>
        <div style="line-height: 1.5; margin-bottom: 15px;">${note.text}</div>
        ${note.photos && note.photos.length > 0 ? `
          <div style="display: flex; gap: 10px; flex-wrap: wrap;">
            ${note.photos.map(photo => `
              <img src="${photo}" style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px; border: 2px solid #555; cursor: pointer;" 
                   onclick="gallery.openPhotoModal('${photo}', '${note.mood}', '${note.date}', '${note.text.replace(/'/g, "\\'")}')">
            `).join('')}
          </div>
        ` : ''}
      `;
      
      container.appendChild(noteCard);
      
      // Add delete event listener
      const deleteBtn = noteCard.querySelector('.delete-note-btn');
      deleteBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (confirm('Are you sure you want to delete this note?')) {
          try {
            await deleteNote(note.id);
            showSuccessMessage('Note deleted successfully!');
            renderNotesForDate(currentDate); // Refresh the display
          } catch (error) {
            alert('Failed to delete note. Please try again.');
          }
        }
      });
    });
  } catch (error) {
    console.error('Error rendering notes:', error);
    container.innerHTML = '<div style="color: #ff6b6b; text-align: center;">Error loading notes</div>';
  }
}

// ==========================
// NOTE POPUP FUNCTIONALITY
// ==========================
function initializeNotePopup() {
  const addNoteBtn = document.getElementById('addNoteBtn');
  const overlay = document.getElementById('overlay');
  const closeNoteBtn = document.getElementById('closeNote');
  const saveNoteBtn = document.getElementById('saveNote');
  const moodSelector = document.getElementById('moodSelector');
  const moodPopup = document.getElementById('moodPopup');
  const emojis = moodPopup.querySelectorAll('.emojis span');
  const moodIcon = document.getElementById('moodIcon');
  const moodText = document.getElementById('moodText');
  const noteDate = document.getElementById('noteDate');
  const noteTime = document.getElementById('noteTime');
  const datePickerBtn = document.getElementById('datePickerBtn');
  const popupCalendar = document.getElementById('calendarPopup');
  const popupCalendarMonthYear = document.getElementById('popupCalendarMonthYear');
  const popupCalendarGrid = document.getElementById('popupCalendarGrid');
  const popupPrevMonthBtn = document.getElementById('popupPrevMonth');
  const popupNextMonthBtn = document.getElementById('popupNextMonth');
  const takePhotoBtn = document.getElementById('takePhotoBtn');
  const fromDeviceBtn = document.getElementById('fromDeviceBtn');
  const noteTextarea = document.getElementById('noteTextarea');
  const photoPreviewContainer = document.getElementById('photoPreviewContainer');

  let currentPhotos = [];

  // Open note popup
  addNoteBtn.addEventListener('click', () => {
    // Reset form
    moodIcon.textContent = '😊';
    moodText.textContent = 'Happy';
    noteTextarea.value = '';
    currentPhotos = [];
    photoPreviewContainer.innerHTML = '';
    
    // Set current date and time
    updatePopupDateTime();
    
    // Show overlay
    overlay.classList.add('active');
  });

  // Close note popup
  closeNoteBtn.addEventListener('click', () => {
    overlay.classList.remove('active');
  });

  // Save note - FIXED DATE HANDLING
  saveNoteBtn.addEventListener('click', async () => {
      const noteText = noteTextarea.value.trim();
      if (!noteText) {
        alert('Please write something in your note');
        return;
      }

      // Use the selected date from popupCalendarDate
      const selectedDate = new Date(popupCalendarDate);
      const now = new Date();
      
      // Set the time to current time but keep the selected date
      selectedDate.setHours(now.getHours(), now.getMinutes(), now.getSeconds(), now.getMilliseconds());
      
      // Format date for backend - use ISO string but ensure it represents the correct local date
      const year = selectedDate.getFullYear();
      const month = String(selectedDate.getMonth() + 1).padStart(2, '0');
      const day = String(selectedDate.getDate()).padStart(2, '0');
      const hours = String(selectedDate.getHours()).padStart(2, '0');
      const minutes = String(selectedDate.getMinutes()).padStart(2, '0');
      const seconds = String(selectedDate.getSeconds()).padStart(2, '0');
      
      // Create ISO string in local timezone
      const localISODate = `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`;
      
      const note = {
          mood: moodIcon.textContent,
          date: localISODate,
          text: noteText,
          photos: [...currentPhotos]
      };

      try {
          await saveNote(note);
          showSuccessMessage('Note saved successfully!');
          overlay.classList.remove('active');
          
          // Refresh display if on home page and the saved note is for the current date
          if (currentPage === 'home') {
            const noteDateObj = new Date(localISODate);
            if (areDatesEqual(noteDateObj, currentDate)) {
              renderNotesForDate(currentDate);
            }
          }
      } catch (error) {
        console.error('Save note error:', error);
        alert('Failed to save note. Please try again.');
      }
  });

  // Mood selection
  moodSelector.addEventListener('click', () => {
    moodPopup.classList.toggle('active');
  });

  emojis.forEach(emoji => {
    emoji.addEventListener('click', () => {
      moodIcon.textContent = emoji.textContent;
      moodText.textContent = moodMap[emoji.textContent];
      moodPopup.classList.remove('active');
    });
  });

  // Date picker
  datePickerBtn.addEventListener('click', () => {
    popupCalendar.classList.toggle('active');
    datePickerBtn.classList.toggle('active');
    generatePopupCalendar(popupCalendarDate);
  });

  // Popup calendar navigation
  popupPrevMonthBtn.addEventListener('click', () => {
    popupCalendarDate.setMonth(popupCalendarDate.getMonth() - 1);
    generatePopupCalendar(popupCalendarDate);
  });

  popupNextMonthBtn.addEventListener('click', () => {
    popupCalendarDate.setMonth(popupCalendarDate.getMonth() + 1);
    generatePopupCalendar(popupCalendarDate);
  });

  // Photo handling - USING MEDIADEVICES API FOR DIRECT CAMERA ACCESS
  takePhotoBtn.addEventListener('click', async () => {
    try {
      // Check if mediaDevices API is available
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        alert('Camera access is not supported in your browser. Please use the file upload instead.');
        return;
      }
      
      // Access camera
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment' },
        audio: false 
      });
      
      // Create camera preview
      const cameraModal = document.createElement('div');
      cameraModal.style.position = 'fixed';
      cameraModal.style.top = '0';
      cameraModal.style.left = '0';
      cameraModal.style.width = '100%';
      cameraModal.style.height = '100%';
      cameraModal.style.backgroundColor = 'rgba(0,0,0,0.9)';
      cameraModal.style.zIndex = '10000';
      cameraModal.style.display = 'flex';
      cameraModal.style.flexDirection = 'column';
      cameraModal.style.alignItems = 'center';
      cameraModal.style.justifyContent = 'center';
      
      const video = document.createElement('video');
      video.style.width = '100%';
      video.style.maxWidth = '500px';
      video.style.borderRadius = '10px';
      video.autoplay = true;
      video.srcObject = stream;
      
      const buttonContainer = document.createElement('div');
      buttonContainer.style.marginTop = '20px';
      buttonContainer.style.display = 'flex';
      buttonContainer.style.gap = '20px';
      
      const captureBtn = document.createElement('button');
      captureBtn.textContent = '📸 Capture';
      captureBtn.style.padding = '10px 20px';
      captureBtn.style.background = '#6b8c74';
      captureBtn.style.color = 'white';
      captureBtn.style.border = 'none';
      captureBtn.style.borderRadius = '5px';
      captureBtn.style.cursor = 'pointer';
      captureBtn.style.fontSize = '16px';
      
      const cancelBtn = document.createElement('button');
      cancelBtn.textContent = '❌ Cancel';
      cancelBtn.style.padding = '10px 20px';
      cancelBtn.style.background = '#ff4d4d';
      cancelBtn.style.color = 'white';
      cancelBtn.style.border = 'none';
      cancelBtn.style.borderRadius = '5px';
      cancelBtn.style.cursor = 'pointer';
      cancelBtn.style.fontSize = '16px';
      
      buttonContainer.appendChild(captureBtn);
      buttonContainer.appendChild(cancelBtn);
      
      cameraModal.appendChild(video);
      cameraModal.appendChild(buttonContainer);
      document.body.appendChild(cameraModal);
      
      // Capture photo
      captureBtn.addEventListener('click', () => {
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        canvas.width = video.videoWidth;
        canvas.height = video.videoHeight;
        context.drawImage(video, 0, 0, canvas.width, canvas.height);
        
        // Convert to data URL
        const photoData = canvas.toDataURL('image/jpeg');
        currentPhotos.push(photoData);
        
        // Create photo preview
        const photoItem = document.createElement('div');
        photoItem.className = 'photo-item';
        photoItem.style.position = 'relative';
        photoItem.style.display = 'inline-block';
        photoItem.style.margin = '5px';
        
        photoItem.innerHTML = `
          <img src="${photoData}" style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px; border: 2px solid white;">
          <button class="removePhotoBtn" style="position: absolute; top: -5px; right: -5px; background: #ff4d4d; color: white; border: none; border-radius: 50%; width: 20px; height: 20px; font-size: 12px; cursor: pointer;">×</button>
        `;
        
        photoPreviewContainer.appendChild(photoItem);
        
        // Add remove functionality
        const removeBtn = photoItem.querySelector('.removePhotoBtn');
        removeBtn.addEventListener('click', () => {
          const index = currentPhotos.indexOf(photoData);
          if (index > -1) {
            currentPhotos.splice(index, 1);
          }
          photoItem.remove();
        });
        
        // Clean up
        stream.getTracks().forEach(track => track.stop());
        document.body.removeChild(cameraModal);
      });
      
      // Cancel camera
      cancelBtn.addEventListener('click', () => {
        stream.getTracks().forEach(track => track.stop());
        document.body.removeChild(cameraModal);
      });
      
    } catch (error) {
      console.error('Error accessing camera:', error);
      alert('Could not access camera. Please check permissions or use file upload.');
      
      // Fallback to file input
      const cameraInput = document.createElement('input');
      cameraInput.type = 'file';
      cameraInput.accept = 'image/*';
      cameraInput.capture = 'environment';
      cameraInput.style.display = 'none';
      
      cameraInput.addEventListener('change', function(e) {
        handlePhotoSelection(e);
        document.body.removeChild(cameraInput);
      });
      
      document.body.appendChild(cameraInput);
      cameraInput.click();
    }
  });

  fromDeviceBtn.addEventListener('click', () => {
    const fileInput = document.createElement('input');
    fileInput.type = 'file';
    fileInput.accept = 'image/*';
    fileInput.multiple = true;
    fileInput.style.display = 'none';
    
    fileInput.addEventListener('change', function(e) {
      handlePhotoSelection(e);
      document.body.removeChild(fileInput);
    });
    
    document.body.appendChild(fileInput);
    fileInput.click();
  });

  function handlePhotoSelection(e) {
    const files = e.target.files;
    
    if (!files || files.length === 0) return;
    
    for (let file of files) {
      const reader = new FileReader();
      
      reader.onload = (event) => {
        const photoData = event.target.result;
        currentPhotos.push(photoData);
        
        const photoItem = document.createElement('div');
        photoItem.className = 'photo-item';
        photoItem.style.position = 'relative';
        photoItem.style.display = 'inline-block';
        photoItem.style.margin = '5px';
        
        photoItem.innerHTML = `
          <img src="${photoData}" style="width: 80px; height: 80px; object-fit: cover; border-radius: 8px; border: 2px solid white;">
          <button class="removePhotoBtn" style="position: absolute; top: -5px; right: -5px; background: #ff4d4d; color: white; border: none; border-radius: 50%; width: 20px; height: 20px; font-size: 12px; cursor: pointer;">×</button>
        `;
        
        photoPreviewContainer.appendChild(photoItem);
        
        const removeBtn = photoItem.querySelector('.removePhotoBtn');
        removeBtn.addEventListener('click', () => {
          const index = currentPhotos.indexOf(photoData);
          if (index > -1) {
            currentPhotos.splice(index, 1);
          }
          photoItem.remove();
        });
      };
      
      reader.readAsDataURL(file);
    }
  }

  function updatePopupDateTime() {
    const now = new Date();
    noteDate.textContent = now.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    noteTime.textContent = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
    popupCalendarDate = new Date(now);
  }

  function generatePopupCalendar(date) {
    const year = date.getFullYear();
    const month = date.getMonth();
    
    // Update calendar header
    popupCalendarMonthYear.textContent = date.toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    
    // Clear previous calendar
    popupCalendarGrid.innerHTML = '';
    
    // Add day headers
    const daysOfWeek = ['S', 'M', 'T', 'W', 'T', 'F', 'S'];
    daysOfWeek.forEach(day => {
      const dayElement = document.createElement('div');
      dayElement.className = 'calendar-day';
      dayElement.textContent = day;
      popupCalendarGrid.appendChild(dayElement);
    });
    
    // Get first day of month and number of days
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDay; i++) {
      const emptyCell = document.createElement('div');
      emptyCell.className = 'calendar-date other-month';
      popupCalendarGrid.appendChild(emptyCell);
    }
    
    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const dateCell = document.createElement('div');
      dateCell.className = 'calendar-date';
      dateCell.textContent = day;
      
      const cellDate = new Date(year, month, day);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      
      if (cellDate.getTime() === today.getTime()) {
        dateCell.classList.add('selected');
      }
      
      dateCell.addEventListener('click', () => {
        popupCalendarDate = new Date(year, month, day);
        noteDate.textContent = popupCalendarDate.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
        popupCalendar.classList.remove('active');
        datePickerBtn.classList.remove('active');
      });
      
      popupCalendarGrid.appendChild(dateCell);
    }
    
    // Disable next month button if it's the current month
    const today = new Date();
    const isCurrentMonth = date.getMonth() === today.getMonth() && date.getFullYear() === today.getFullYear();
    popupNextMonthBtn.classList.toggle('disabled', isCurrentMonth);
  }

  // Hide popups when clicking outside
  document.addEventListener('click', (e) => {
    if (!moodPopup.contains(e.target) && e.target !== moodSelector && !moodSelector.contains(e.target)) {
      moodPopup.classList.remove('active');
    }
    
    if (!popupCalendar.contains(e.target) && e.target !== datePickerBtn && !datePickerBtn.contains(e.target)) {
      popupCalendar.classList.remove('active');
      datePickerBtn.classList.remove('active');
    }
  });
}

function showSuccessMessage(message) {
  const messageElement = document.getElementById('successMessage');
  messageElement.textContent = message;
  messageElement.classList.add('show');
  
  setTimeout(() => {
    messageElement.classList.remove('show');
  }, 3000);
}

// ==========================
// GALLERY FUNCTIONALITY
// ==========================
const gallery = {
  photos: [],
  
  async loadPhotos() {
    try {
      const dateFilter = document.getElementById('dateFilter').value;
      const moodFilter = document.getElementById('moodFilter').value;
      this.photos = await fetchPhotos(dateFilter, moodFilter);
    } catch (error) {
      console.error('Error loading photos:', error);
      this.photos = [];
    }
  },
  
  setupFilters() {
    const dateFilter = document.getElementById('dateFilter');
    const moodFilter = document.getElementById('moodFilter');
    
    dateFilter.addEventListener('change', () => this.renderGallery());
    moodFilter.addEventListener('change', () => this.renderGallery());
  },
  
  async renderGallery() {
    const container = document.getElementById('galleryContainer');
    const noPhotos = document.getElementById('noPhotos');
    
    await this.loadPhotos();
    
    if (this.photos.length === 0) {
      container.innerHTML = '';
      noPhotos.style.display = 'block';
      return;
    }
    
    noPhotos.style.display = 'none';
    container.innerHTML = '';
    
    // Sort by date (newest first)
    this.photos.sort((a, b) => new Date(b.date) - new Date(a.date));
    
    // Create photo cards
    this.photos.forEach(photo => {
      const photoCard = document.createElement('div');
      photoCard.className = 'photo-card';
      
      const photoDate = new Date(photo.date);
      const dateString = photoDate.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
      const previewText = photo.text.length > 50 ? photo.text.substring(0, 50) + '...' : photo.text;
      
      photoCard.innerHTML = `
        <img src="${photo.src}" class="photo-thumbnail" alt="Journal photo">
        <div class="photo-details">
          <div class="photo-mood">${photo.mood}</div>
          <div class="photo-date">${dateString}</div>
          <div class="photo-preview">${previewText}</div>
          <button class="delete-photo-btn" data-note-id="${photo.note_id}" style="margin-top: 5px; background: #ff4d4d; color: white; border: none; border-radius: 3px; padding: 3px 6px; font-size: 10px; cursor: pointer;">Delete</button>
        </div>
      `;
      
      photoCard.addEventListener('click', (e) => {
        // Don't open modal if delete button was clicked
        if (!e.target.classList.contains('delete-photo-btn')) {
          this.openPhotoModal(photo.src, photo.mood, photo.date, photo.text);
        }
      });
      
      // Add delete event listener
      const deleteBtn = photoCard.querySelector('.delete-photo-btn');
      deleteBtn.addEventListener('click', async (e) => {
        e.stopPropagation();
        if (confirm('Are you sure you want to delete this photo?')) {
          try {
            await deleteNote(photo.note_id);
            showSuccessMessage('Photo deleted successfully!');
            this.renderGallery(); // Refresh gallery
          } catch (error) {
            alert('Failed to delete photo. Please try again.');
          }
        }
      });
      
      container.appendChild(photoCard);
    });
  },
  
  openPhotoModal(src, mood, date, text) {
    const modal = document.getElementById('photoModal');
    const modalImage = document.getElementById('modalImage');
    const modalMood = document.getElementById('modalMood');
    const modalDate = document.getElementById('modalDate');
    const modalNote = document.getElementById('modalNote');
    const closeModal = document.getElementById('closeModal');
    
    modalImage.src = src;
    modalMood.textContent = mood;
    
    const dateObj = new Date(date);
    modalDate.textContent = dateObj.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit'
    });
    
    modalNote.textContent = text;
    
    modal.style.display = 'block';
    
    closeModal.onclick = () => {
      modal.style.display = 'none';
    };
    
    window.onclick = (e) => {
      if (e.target === modal) {
        modal.style.display = 'none';
      }
    };
  }
};

function initializeGallery() {
  gallery.setupFilters();
}

// ==========================
// CALENDAR FUNCTIONALITY - FIXED VERSION
// ==========================
const calendar = {
  currentDate: new Date(),
  
  initialize() {
    this.setupNavigation();
    this.renderCalendar();
  },
  
  setupNavigation() {
    const prevYearBtn = document.getElementById('prevYear');
    const prevMonthBtn = document.getElementById('prevMonth');
    const nextMonthBtn = document.getElementById('nextMonth');
    const nextYearBtn = document.getElementById('nextYear');
    
    if (prevYearBtn) {
      prevYearBtn.addEventListener('click', () => {
        this.currentDate.setFullYear(this.currentDate.getFullYear() - 1);
        this.renderCalendar();
      });
    }
    
    if (prevMonthBtn) {
      prevMonthBtn.addEventListener('click', () => {
        this.currentDate.setMonth(this.currentDate.getMonth() - 1);
        this.renderCalendar();
      });
    }
    
    if (nextMonthBtn) {
      nextMonthBtn.addEventListener('click', () => {
        this.currentDate.setMonth(this.currentDate.getMonth() + 1);
        this.renderCalendar();
      });
    }
    
    if (nextYearBtn) {
      nextYearBtn.addEventListener('click', () => {
        this.currentDate.setFullYear(this.currentDate.getFullYear() + 1);
        this.renderCalendar();
      });
    }
  },
  
  async renderCalendar() {
    const calendarGrid = document.getElementById('calendarGrid');
    const currentMonthYear = document.getElementById('currentMonthYear');
    
    if (!calendarGrid || !currentMonthYear) {
      console.error('Calendar elements not found');
      return;
    }
    
    const year = this.currentDate.getFullYear();
    const month = this.currentDate.getMonth();
    
    // Update header
    currentMonthYear.textContent = this.currentDate.toLocaleDateString('en-US', { 
      month: 'long', 
      year: 'numeric' 
    });
    
    // Clear previous calendar
    calendarGrid.innerHTML = '';
    
    // Add day headers
    const daysOfWeek = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    daysOfWeek.forEach(day => {
      const dayHeader = document.createElement('div');
      dayHeader.className = 'calendar-day-header';
      dayHeader.textContent = day;
      calendarGrid.appendChild(dayHeader);
    });
    
    // Get first day of month and number of days
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startingDay = firstDay.getDay();
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < startingDay; i++) {
      const emptyCell = document.createElement('div');
      emptyCell.className = 'calendar-day other-month';
      calendarGrid.appendChild(emptyCell);
    }
    
    try {
      // Fetch calendar data from backend
      const response = await fetch(`${API_BASE}/calendar/${year}/${month + 1}`);
      if (!response.ok) throw new Error('Failed to fetch calendar data');
      const calendarData = await response.json();
      
      // Add days of the month
      for (let day = 1; day <= daysInMonth; day++) {
        const dayCell = document.createElement('div');
        dayCell.className = 'calendar-day';
        
        const cellDate = new Date(year, month, day);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        cellDate.setHours(0, 0, 0, 0);
        
        // Check if this day has notes - handle both object and array response formats
        const dateString = formatDateForAPI(cellDate);
        let dayNotes = [];
        
        if (Array.isArray(calendarData)) {
          // If backend returns array of dates with notes
          const dayData = calendarData.find(d => d.date === dateString);
          dayNotes = dayData ? dayData.notes || [] : [];
        } else if (calendarData[dateString]) {
          // If backend returns object with date keys
          dayNotes = calendarData[dateString].notes || [];
        }
        
        const dayNumber = document.createElement('div');
        dayNumber.className = 'day-number';
        dayNumber.textContent = day;
        
        if (cellDate.getTime() === today.getTime()) {
          dayCell.classList.add('today');
        }
        
        dayCell.appendChild(dayNumber);
        
        if (dayNotes.length > 0) {
          const moodElement = document.createElement('div');
          moodElement.className = 'day-mood';
          
          // Get dominant mood
          const moodCounts = {};
          dayNotes.forEach(note => {
            moodCounts[note.mood] = (moodCounts[note.mood] || 0) + 1;
          });
          
          const dominantMood = Object.keys(moodCounts).reduce((a, b) => 
            moodCounts[a] > moodCounts[b] ? a : b
          );
          
          moodElement.textContent = dominantMood;
          dayCell.appendChild(moodElement);
          
          // Add mood indicator
          const moodIndicator = document.createElement('div');
          moodIndicator.className = 'mood-indicator';
          
          switch (dominantMood) {
            case '😊': moodIndicator.classList.add('mood-happy'); break;
            case '🙂': moodIndicator.classList.add('mood-content'); break;
            case '😐': moodIndicator.classList.add('mood-neutral'); break;
            case '🙁': moodIndicator.classList.add('mood-sad'); break;
            case '😣': moodIndicator.classList.add('mood-stressed'); break;
          }
          
          dayCell.appendChild(moodIndicator);
          
          // Add preview text if available
          if (dayNotes[0].text) {
            const previewElement = document.createElement('div');
            previewElement.className = 'day-preview';
            const previewText = dayNotes[0].text;
            previewElement.textContent = previewText.substring(0, 30) + 
                                      (previewText.length > 30 ? '...' : '');
            dayCell.appendChild(previewElement);
          }
        }
        
        // Add click event to show day notes
        dayCell.addEventListener('click', () => {
          this.showDayNotes(cellDate, dayNotes);
        });
        
        calendarGrid.appendChild(dayCell);
      }
      
      // Fill remaining cells to complete the grid (6 rows)
      const totalCells = 42; // 6 weeks * 7 days
      const currentCells = startingDay + daysInMonth;
      const remainingCells = totalCells - currentCells;
      
      for (let i = 0; i < remainingCells; i++) {
        const emptyCell = document.createElement('div');
        emptyCell.className = 'calendar-day other-month';
        calendarGrid.appendChild(emptyCell);
      }
      
    } catch (error) {
      console.error('Error rendering calendar:', error);
      // Fallback: render calendar without data
      this.renderCalendarFallback(calendarGrid, year, month, daysInMonth, startingDay);
    }
  },

  renderCalendarFallback(calendarGrid, year, month, daysInMonth, startingDay) {
    // Add days of the month without data
    for (let day = 1; day <= daysInMonth; day++) {
      const dayCell = document.createElement('div');
      dayCell.className = 'calendar-day';
      
      const cellDate = new Date(year, month, day);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      cellDate.setHours(0, 0, 0, 0);
      
      if (cellDate.getTime() === today.getTime()) {
        dayCell.classList.add('today');
      }
      
      const dayNumber = document.createElement('div');
      dayNumber.className = 'day-number';
      dayNumber.textContent = day;
      dayCell.appendChild(dayNumber);
      
      dayCell.addEventListener('click', () => {
        this.showDayNotes(cellDate, []);
      });
      
      calendarGrid.appendChild(dayCell);
    }
    
    // Fill remaining cells
    const totalCells = 42;
    const currentCells = startingDay + daysInMonth;
    const remainingCells = totalCells - currentCells;
    
    for (let i = 0; i < remainingCells; i++) {
      const emptyCell = document.createElement('div');
      emptyCell.className = 'calendar-day other-month';
      calendarGrid.appendChild(emptyCell);
    }
  },
  
  async showDayNotes(date, notes) {
    const modal = document.getElementById('dayModal');
    const modalDateTitle = document.getElementById('modalDateTitle');
    const dayNotes = document.getElementById('dayNotes');
    const closeModal = document.getElementById('closeDayModal');
    
    if (!modal || !modalDateTitle || !dayNotes) {
      console.error('Day modal elements not found');
      return;
    }
    
    // Set modal title
    modalDateTitle.textContent = date.toLocaleDateString('en-US', { 
      weekday: 'long', 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric' 
    });
    
    // Clear previous notes
    dayNotes.innerHTML = '';
    
    // If no notes provided, fetch them
    if (notes.length === 0) {
      try {
        const dateString = formatDateForAPI(date);
        notes = await fetchNotes(dateString);
      } catch (error) {
        console.error('Error fetching day notes:', error);
      }
    }
    
    if (notes.length === 0) {
      dayNotes.innerHTML = `
        <div class="no-notes">
          <div class="no-notes-icon">📝</div>
          <div>No entries for this day</div>
        </div>
      `;
    } else {
      // Sort notes by time (newest first)
      notes.sort((a, b) => new Date(b.date) - new Date(a.date));
      
      // Create note items
      notes.forEach(note => {
        const noteItem = document.createElement('div');
        noteItem.className = 'note-item';
        
        const noteDate = new Date(note.date);
        const timeString = noteDate.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
        
        noteItem.innerHTML = `
          <div class="note-header">
            <div class="note-mood">${note.mood || ''}</div>
            <div class="note-time">${timeString}</div>
          </div>
          <div class="note-text">${note.text || ''}</div>
          ${note.photos && note.photos.length > 0 ? `
            <div class="note-photos">
              ${note.photos.map(photo => `
                <img src="${photo}" class="note-photo" 
                     onclick="gallery.openPhotoModal('${photo}', '${note.mood || ''}', '${note.date}', '${note.text.replace(/'/g, "\\'")}')">
              `).join('')}
            </div>
          ` : ''}
          <button class="delete-note-btn" data-note-id="${note.id}" style="margin-top: 10px; background: #ff4d4d; color: white; border: none; border-radius: 5px; padding: 5px 10px; cursor: pointer;">Delete</button>
        `;
        
        dayNotes.appendChild(noteItem);
        
        // Add delete event listener
        const deleteBtn = noteItem.querySelector('.delete-note-btn');
        if (deleteBtn) {
          deleteBtn.addEventListener('click', async (e) => {
            e.stopPropagation();
            if (confirm('Are you sure you want to delete this note?')) {
              try {
                await deleteNote(note.id);
                showSuccessMessage('Note deleted successfully!');
                modal.style.display = 'none';
                this.renderCalendar(); // Refresh calendar
              } catch (error) {
                alert('Failed to delete note. Please try again.');
              }
            }
          });
        }
      });
    }
    
    modal.style.display = 'block';
    
    if (closeModal) {
      closeModal.onclick = () => {
        modal.style.display = 'none';
      };
    }
    
    window.onclick = (e) => {
      if (e.target === modal) {
        modal.style.display = 'none';
      }
    };
  }
};

function initializeCalendar() {
  calendar.initialize();
}